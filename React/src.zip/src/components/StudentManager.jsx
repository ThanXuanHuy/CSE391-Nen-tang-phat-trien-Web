import React, { useState, useEffect } from "react";
import '../StudentManager.css';

export default function StudentManager() {
  const initialStudents = [
    {
      code: "2251162035",
      name: "Thân Xuân Huy",
      email: "huykoisd02@gmail.com",
      gender: "Nam",
      dob: "2004-12-31",
      note: "",
    },
    {
      code: "2251162168",
      name: "Đặng Thị Thu Thủy",
      email: "dangthuycm02@gmail.com",
      gender: "Nữ",
      dob: "2004-07-27",
      note: "",
    },
    {
      code: "2251162093",
      name: "Vũ Thị Thanh Nhài",
      email: "nhaivutb02@gmail.com",
      gender: "Nữ",
      dob: "2004-01-29",
      note: "",
    },
  ];

  const [students, setStudents] = useState(initialStudents);
  const [form, setForm] = useState({
    code: "",
    name: "",
    email: "",
    dob: "",
    gender: "",
    note: "",
  });
  const [editingIndex, setEditingIndex] = useState(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(() => setMessage(""), 3000);
    return () => clearTimeout(timer);
  }, [message]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    if (!form.code.trim()) return "Mã sinh viên không được để trống";
    if (!form.name.trim()) return "Họ và tên không được để trống";
    if (!form.email.trim()) return "Email không được để trống";
    const re = /^\S+@\S+\.\S+$/;
    if (!re.test(form.email)) return "Email không hợp lệ";
    if (!form.dob) return "Vui lòng chọn ngày sinh";
    if (!form.gender) return "Vui lòng chọn giới tính";
    return null;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const err = validate();
    if (err) {
      setMessage(err);
      return;
    }
    if (editingIndex === null) {
      setStudents((prev) => [...prev, { ...form }]);
      setMessage("Thêm sinh viên thành công!");
    } else {
      setStudents((prev) => {
        const copy = [...prev];
        copy[editingIndex] = { ...form };
        return copy;
      });
      setMessage("Cập nhật thành công!");
      setEditingIndex(null);
    }
    setForm({ code: "", name: "", email: "", dob: "", gender: "", note: "" });
  };

  const handleEdit = (index) => {
    const s = students[index];
    setForm({ ...s });
    setEditingIndex(index);
  };

  const handleDelete = (index) => {
    if (!window.confirm("Bạn có chắc chắn muốn xoá?")) return;
    setStudents((prev) => prev.filter((_, i) => i !== index));
    setMessage("Xoá thành công!");
    if (editingIndex === index) {
      setEditingIndex(null);
      setForm({ code: "", name: "", email: "", dob: "", gender: "", note: "" });
    }
  };

  const handleCancelEdit = () => {
    setEditingIndex(null);
    setForm({ code: "", name: "", email: "", dob: "", gender: "", note: "" });
  };

  return (
    <>
      <nav className="navbar">
        <h2>Quản lý sinh viên</h2>
      </nav>
      <main className="container">
        <section className="form-section">
          <h3>Form thêm sinh viên</h3>
          {message && <div id="thongBao">{message}</div>}
          <form onSubmit={handleSubmit}>
            <div>
              <label htmlFor="code">Mã sinh viên:</label>
              <input type="text" id="code" name="code" value={form.code} onChange={handleChange} required />
            </div>
            <div>
              <label htmlFor="name">Họ và tên:</label>
              <input type="text" id="name" name="name" value={form.name} onChange={handleChange} required
              />
            </div>
            <div>
              <label htmlFor="email">Email:</label>
              <input type="email" id="email" name="email" value={form.email} onChange={handleChange} required />
            </div>
            <div>
              <label htmlFor="dob">Ngày sinh:</label>
              <input type="date" id="dob" name="dob" value={form.dob} onChange={handleChange} required />
            </div>
            <div>
              <label>Giới tính:</label>
              <input type="radio" id="nam" name="gender" value="Nam" checked={form.gender === "Nam"} onChange={handleChange} />
              <label htmlFor="nam">Nam</label>
              <input type="radio" id="nu" name="gender" value="Nữ" checked={form.gender === "Nữ"} onChange={handleChange} />
              <label htmlFor="nu">Nữ</label>
            </div>
            <div>
              <label htmlFor="note">Ghi chú:</label>
              <textarea id="note" name="note" rows={4} value={form.note} onChange={handleChange} />
            </div>
            <div style={{ textAlign: "center", marginTop: "10px" }}>
              <button type="submit" id="btnThem" className={editingIndex === null ? "btn_them" : "btn"}> {editingIndex === null ? "Thêm sinh viên" : "Cập nhật"}
              </button>
              {editingIndex !== null && ( <button   type="button"   className="btn"   onClick={handleCancelEdit}   style={{ marginLeft: "10px" }} >   Huỷ
                </button>
              )}
            </div>
          </form>
        </section>

        <section className="table-section">
          <h3>Danh sách sinh viên</h3>
          <table id="bangSinhVien">
            <thead>
              <tr>
                <th>STT</th>
                <th>Mã SV</th>
                <th>Họ tên</th>
                <th>Email</th>
                <th>Giới tính</th>
                <th>Ngày sinh</th>
                <th>Hành động</th>
              </tr>
            </thead>
            <tbody>
              {students.length > 0 ? (
                students.map((s, i) => (
                  <tr key={i}>
                    <td>{i + 1}</td>
                    <td>{s.code}</td>
                    <td>{s.name}</td>
                    <td>{s.email}</td>
                    <td>{s.gender}</td>
                    <td>{s.dob}</td>
                    <td>
                      <button className="btn" onClick={() => handleEdit(i)}>
                        Sửa
                      </button>{" "}
                      <button className="btn" onClick={() => handleDelete(i)}>
                        Xóa
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7}>Chưa có sinh viên nào</td>
                </tr>
              )}
            </tbody>
          </table>
        </section>
      </main>
    </>
  );
}
