import React from 'react';
import StudentManager from './components/StudentManager';

function App() {
  return <StudentManager />;
}

export default App;
